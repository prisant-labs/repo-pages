Templates for the old cover sheet. Do not use.
